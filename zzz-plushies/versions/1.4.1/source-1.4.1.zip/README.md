# ZZZ Plushies — Forge 1.20.1

Small, placeable, seated decorative plushies made from the selected Zenless Zone Zero Minecraft skins. Each agent has its own block and item. The plushes face the player when placed, sit flush on the ground, can be broken by hand and drop themselves. They appear in the **ZZZ Plushies** creative tab.

In survival, craft four **Plush Bases** with one white wool surrounded by four string, then use a stonecutter to choose a character plush. This recipe keeps the character selection in one familiar screen.

The 58 currently selected agents are listed with original skin artists and links in [SKIN_SOURCES.md](SKIN_SOURCES.md). Pyrois and Claret Flint need identifiable source skins before they can be added. Roxy is included in advance of her September 30, 2026 release. NameMC does not identify the Starlight Billy skin by name; verify that visual before distributing the mod.

## Build

Requires Java 17. Run `gradlew.bat build` from this directory. The mod JAR will be in `build/libs/` and goes in the `mods` folder of a Forge 1.20.1 client and server. No other mods are required.

The resources can be regenerated from `../assets/zzz-plushie-skins/` by running `python generate_assets.py` with Pillow installed.

Version 1.3.0 uses the supplied `llary-plush` Blockbench model as the geometry reference for the six shared body parts: a 10 x 9 x 10 head, 6 x 6 x 6 torso, short sideways arms, and seated legs. It keeps each agent's original Minecraft skin and clothing layers. The four extra head decorations in that character-specific model are not applied to every ZZZ character. Earlier JARs and source snapshots are preserved in `versions/1.0.0/`, `versions/1.1.0/`, and `versions/1.2.0/`.

Version 1.4.0 renders the placed plushes at 60% of that geometry (nine pixels tall) and gives each inventory item a live 3D preview of its own plush model. The prior 1.3.0 build and source are preserved in `versions/1.3.0/`.

Version 1.4.1 increases the plush scale to 65% of the reference geometry (9.75 pixels tall). The prior 1.4.0 build and source are preserved in `versions/1.4.0/`.

This is an unofficial fan project. Do not redistribute the third-party skins without checking their creators' terms.
