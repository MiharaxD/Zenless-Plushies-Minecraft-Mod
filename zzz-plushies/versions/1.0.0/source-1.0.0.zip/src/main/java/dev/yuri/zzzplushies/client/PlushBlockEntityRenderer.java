package dev.yuri.zzzplushies.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import dev.yuri.zzzplushies.ZzzPlushies;
import dev.yuri.zzzplushies.block.PlushBlock;
import dev.yuri.zzzplushies.block.PlushBlockEntity;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.registries.ForgeRegistries;

public final class PlushBlockEntityRenderer implements BlockEntityRenderer<PlushBlockEntity> {
    private final PlayerModel<LivingEntity> model;

    public PlushBlockEntityRenderer(BlockEntityRendererProvider.Context context) {
        model = new PlayerModel<>(context.bakeLayer(ModelLayers.PLAYER), false);
        model.leftLeg.xRot = -1.20F;
        model.rightLeg.xRot = -1.20F;
        model.leftLeg.yRot = -0.16F;
        model.rightLeg.yRot = 0.16F;
        model.leftArm.xRot = -0.30F;
        model.rightArm.xRot = -0.30F;
        model.leftArm.zRot = -0.12F;
        model.rightArm.zRot = 0.12F;
        model.leftSleeve.copyFrom(model.leftArm);
        model.rightSleeve.copyFrom(model.rightArm);
        model.leftPants.copyFrom(model.leftLeg);
        model.rightPants.copyFrom(model.rightLeg);
    }

    @Override
    public void render(PlushBlockEntity plush, float partialTick, PoseStack pose,
                       MultiBufferSource buffers, int light, int overlay) {
        ResourceLocation key = ForgeRegistries.BLOCKS.getKey(plush.getBlockState().getBlock());
        if (key == null) return;
        ResourceLocation texture = new ResourceLocation(ZzzPlushies.MOD_ID,
                "textures/entity/" + key.getPath() + ".png");
        VertexConsumer vertices = buffers.getBuffer(RenderType.entityCutoutNoCull(texture));
        pose.pushPose();
        pose.translate(0.5D, 0.69D, 0.5D);
        pose.mulPose(Axis.YP.rotationDegrees(180.0F - plush.getBlockState().getValue(PlushBlock.FACING).toYRot()));

        // The seated body keeps the original skin UVs. Its head is rendered larger for a chibi plush silhouette.
        pose.pushPose();
        pose.scale(0.45F, -0.45F, 0.45F);
        model.body.render(pose, vertices, light, OverlayTexture.NO_OVERLAY);
        model.jacket.render(pose, vertices, light, OverlayTexture.NO_OVERLAY);
        model.leftArm.render(pose, vertices, light, OverlayTexture.NO_OVERLAY);
        model.rightArm.render(pose, vertices, light, OverlayTexture.NO_OVERLAY);
        model.leftSleeve.render(pose, vertices, light, OverlayTexture.NO_OVERLAY);
        model.rightSleeve.render(pose, vertices, light, OverlayTexture.NO_OVERLAY);
        model.leftLeg.render(pose, vertices, light, OverlayTexture.NO_OVERLAY);
        model.rightLeg.render(pose, vertices, light, OverlayTexture.NO_OVERLAY);
        model.leftPants.render(pose, vertices, light, OverlayTexture.NO_OVERLAY);
        model.rightPants.render(pose, vertices, light, OverlayTexture.NO_OVERLAY);
        pose.popPose();

        pose.pushPose();
        pose.scale(0.65F, -0.65F, 0.65F);
        model.head.render(pose, vertices, light, OverlayTexture.NO_OVERLAY);
        model.hat.render(pose, vertices, light, OverlayTexture.NO_OVERLAY);
        pose.popPose();
        pose.popPose();
    }
}
