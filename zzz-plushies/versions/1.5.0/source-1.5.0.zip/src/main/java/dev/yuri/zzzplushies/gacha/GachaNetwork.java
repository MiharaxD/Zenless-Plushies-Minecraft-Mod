package dev.yuri.zzzplushies.gacha;

import dev.yuri.zzzplushies.ZzzPlushies;
import dev.yuri.zzzplushies.client.GachaMusic;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

public final class GachaNetwork {
    private static final String VERSION = "1";
    private static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(ZzzPlushies.MOD_ID, "gacha"), () -> VERSION,
            VERSION::equals, VERSION::equals);

    private GachaNetwork() {}

    public static void register() {
        CHANNEL.registerMessage(0, SpinSound.class, (message, buffer) -> buffer.writeVarInt(message.plushIndex),
                buffer -> new SpinSound(buffer.readVarInt()), (message, contextSupplier) -> {
                    var context = contextSupplier.get();
                    context.enqueueWork(() -> GachaMusic.play(message.plushIndex));
                    context.setPacketHandled(true);
                });
    }

    public static void playFor(ServerPlayer player, int plushIndex) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new SpinSound(plushIndex));
    }

    private record SpinSound(int plushIndex) {}
}
