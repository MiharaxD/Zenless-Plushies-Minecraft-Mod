package dev.yuri.zzzplushies.gacha;

import dev.yuri.zzzplushies.PlushCatalog;
import dev.yuri.zzzplushies.ZzzPlushies;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

@Mod.EventBusSubscriber(modid = ZzzPlushies.MOD_ID)
public final class GachaLogic {
    private static final String KEY = "zzzplushies_gacha";
    private static final Item[] ORES = {Items.IRON_INGOT, Items.GOLD_INGOT, Items.COPPER_INGOT,
            Items.DIAMOND, Items.EMERALD, Items.LAPIS_LAZULI, Items.REDSTONE, Items.NETHERITE_SCRAP,
            Items.RAW_IRON, Items.RAW_GOLD};
    private static final Item[] TOOLS = {Items.IRON_PICKAXE, Items.IRON_AXE, Items.IRON_SHOVEL,
            Items.IRON_SWORD, Items.GOLDEN_PICKAXE, Items.GOLDEN_AXE, Items.DIAMOND_PICKAXE,
            Items.DIAMOND_SWORD, Items.BOW, Items.CROSSBOW};

    private GachaLogic() {}

    public static CompoundTag data(Player player) {
        CompoundTag persisted = player.getPersistentData().getCompound(Player.PERSISTED_NBT_TAG);
        CompoundTag gacha = persisted.getCompound(KEY);
        persisted.put(KEY, gacha);
        player.getPersistentData().put(Player.PERSISTED_NBT_TAG, persisted);
        return gacha;
    }

    public static void select(Player player, int delta) {
        CompoundTag state = data(player);
        int length = PlushCatalog.IDS.length;
        state.putInt("selected", Math.floorMod(state.getInt("selected") + delta, length));
    }

    public static int tapeCount(Player player) {
        int count = 0;
        for (ItemStack stack : player.getInventory().items) {
            if (stack.is(ZzzPlushies.MASTER_TAPE.get())) count += stack.getCount();
        }
        return count;
    }

    public static void spin(ServerPlayer player) {
        if (tapeCount(player) == 0) {
            player.displayClientMessage(Component.translatable("message.zzzplushies.no_tape"), true);
            return;
        }
        for (ItemStack stack : player.getInventory().items) {
            if (stack.is(ZzzPlushies.MASTER_TAPE.get())) {
                stack.shrink(1);
                break;
            }
        }

        CompoundTag state = data(player);
        int pity = Math.max(0, Math.min(74, state.getInt("pity")));
        boolean plush = pity == 74 || player.getRandom().nextFloat() < 0.006F;
        int awardedIndex = -1;
        ItemStack reward;
        if (plush) {
            int chosen = Math.floorMod(state.getInt("selected"), PlushCatalog.IDS.length);
            boolean won = player.getRandom().nextBoolean();
            int index = won ? chosen : Math.floorMod(chosen + 1 + player.getRandom().nextInt(PlushCatalog.IDS.length - 1), PlushCatalog.IDS.length);
            awardedIndex = index;
            reward = new ItemStack(ForgeRegistries.ITEMS.getValue(
                    new net.minecraft.resources.ResourceLocation(ZzzPlushies.MOD_ID, PlushCatalog.IDS[index])));
            state.putInt("pity", 0);
            if (!won) {
                int losses = state.getInt("losses") + 1;
                if (losses >= 2) {
                    give(player, new ItemStack(ZzzPlushies.CHOICE_TOKEN.get()));
                    losses = 0;
                    player.displayClientMessage(Component.translatable("message.zzzplushies.token"), false);
                }
                state.putInt("losses", losses);
            }
            player.displayClientMessage(Component.translatable(won ? "message.zzzplushies.won" : "message.zzzplushies.lost", reward.getHoverName()), false);
        } else {
            state.putInt("pity", pity + 1);
            reward = randomReward(player);
            player.displayClientMessage(Component.translatable("message.zzzplushies.reward", reward.getHoverName()), true);
        }
        give(player, reward);
        GachaNetwork.playFor(player, awardedIndex);
        player.containerMenu.broadcastChanges();
    }

    private static ItemStack randomReward(ServerPlayer player) {
        int roll = player.getRandom().nextInt(100);
        if (roll < 68) {
            int index = player.getRandom().nextInt(ORES.length);
            int count = index == 7 ? 1 : index == 3 || index == 4 ? 1 + player.getRandom().nextInt(3) : 2 + player.getRandom().nextInt(7);
            return new ItemStack(ORES[index], count);
        }
        if (roll < 90) return new ItemStack(TOOLS[player.getRandom().nextInt(TOOLS.length)]);
        ItemStack book = new ItemStack(Items.BOOK);
        return EnchantmentHelper.enchantItem(player.getRandom(), book, 15 + player.getRandom().nextInt(16), true);
    }

    private static void give(ServerPlayer player, ItemStack stack) {
        if (!player.getInventory().add(stack)) player.drop(stack, false);
    }

    @SubscribeEvent
    public static void clonePlayer(PlayerEvent.Clone event) {
        event.getOriginal().reviveCaps();
        CompoundTag oldData = event.getOriginal().getPersistentData();
        if (oldData.contains(Player.PERSISTED_NBT_TAG)) {
            event.getEntity().getPersistentData().put(Player.PERSISTED_NBT_TAG,
                    oldData.getCompound(Player.PERSISTED_NBT_TAG).copy());
        }
        event.getOriginal().invalidateCaps();
    }
}
