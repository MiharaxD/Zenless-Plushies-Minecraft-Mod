package dev.yuri.zzzplushies.client;

import dev.yuri.zzzplushies.ZzzPlushies;
import dev.yuri.zzzplushies.PlushCatalog;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ZzzPlushies.MOD_ID, value = Dist.CLIENT)
public final class GachaMusic {
    private static SimpleSoundInstance playing;
    private static int ticks;
    private static boolean stopBeforeVocal;
    private static int pendingVoice = -1;
    private static SoundInstance voicePlaying;

    private GachaMusic() {}

    public static void play(int plushIndex) {
        Minecraft minecraft = Minecraft.getInstance();
        if (playing != null) minecraft.getSoundManager().stop(playing);
        if (voicePlaying != null) minecraft.getSoundManager().stop(voicePlaying);
        playing = SimpleSoundInstance.forUI(ZzzPlushies.GACHA_SPIN_SOUND.get(), 1.0F, 0.55F);
        ticks = 0;
        stopBeforeVocal = plushIndex < 0;
        pendingVoice = plushIndex;
        voicePlaying = null;
        minecraft.getSoundManager().play(playing);
    }

    @SubscribeEvent
    public static void clientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END || playing == null || Minecraft.getInstance().isPaused()) return;
        ticks++;
        if (ticks == 165 && pendingVoice >= 0 && pendingVoice < PlushCatalog.IDS.length) {
            var voice = ZzzPlushies.AGENT_VOICES.get(PlushCatalog.IDS[pendingVoice]);
            if (voice != null) {
                voicePlaying = SimpleSoundInstance.forUI(voice.get(), 1.0F);
                Minecraft.getInstance().getSoundManager().play(voicePlaying);
            }
            pendingVoice = -1;
        }
        if (stopBeforeVocal && ticks >= 150) {
            Minecraft.getInstance().getSoundManager().stop(playing);
            playing = null;
        }
    }
}
