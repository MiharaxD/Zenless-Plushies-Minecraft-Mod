package dev.yuri.zzzplushies.client;

import dev.yuri.zzzplushies.PlushCatalog;
import dev.yuri.zzzplushies.gacha.GachaMenu;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.registries.ForgeRegistries;

public final class GachaScreen extends AbstractContainerScreen<GachaMenu> {
    public GachaScreen(GachaMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        imageWidth = 220;
        imageHeight = 150;
    }

    @Override
    protected void init() {
        super.init();
        addRenderableWidget(Button.builder(Component.literal("◀"), b -> press(1))
                .bounds(leftPos + 25, topPos + 48, 25, 20).build());
        addRenderableWidget(Button.builder(Component.literal("▶"), b -> press(2))
                .bounds(leftPos + 170, topPos + 48, 25, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("button.zzzplushies.spin"), b -> press(0))
                .bounds(leftPos + 64, topPos + 112, 92, 22).build());
    }

    private void press(int id) {
        Minecraft.getInstance().gameMode.handleInventoryButtonClick(menu.containerId, id);
    }

    @Override
    protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        graphics.fill(leftPos, topPos, leftPos + imageWidth, topPos + imageHeight, 0xFF111725);
        graphics.fill(leftPos + 3, topPos + 3, leftPos + imageWidth - 3, topPos + imageHeight - 3, 0xFF27334B);
        graphics.fill(leftPos + 56, topPos + 31, leftPos + 164, topPos + 85, 0xFF111725);
        String plushId = PlushCatalog.IDS[Math.floorMod(menu.selected(), PlushCatalog.IDS.length)];
        ItemStack plush = new ItemStack(ForgeRegistries.ITEMS.getValue(new ResourceLocation("zzzplushies", plushId)));
        graphics.renderItem(plush, leftPos + 102, topPos + 38);
        graphics.drawCenteredString(font, plush.getHoverName(), leftPos + 110, topPos + 69, 0xFFF5E7CE);
    }

    @Override
    protected void renderLabels(GuiGraphics graphics, int mouseX, int mouseY) {
        graphics.drawCenteredString(font, title, imageWidth / 2, 12, 0xFFF5E7CE);
        graphics.drawString(font, Component.translatable("gui.zzzplushies.tapes", menu.tapes()), 13, 91, 0xFFFFFF, false);
        graphics.drawString(font, Component.translatable("gui.zzzplushies.pity", menu.pity(), 75), 94, 91, 0xFFFFFF, false);
        graphics.drawString(font, Component.translatable("gui.zzzplushies.losses", menu.losses(), 2), 13, 102, 0xF5C6C6, false);
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics);
        super.render(graphics, mouseX, mouseY, partialTick);
        renderTooltip(graphics, mouseX, mouseY);
    }
}
