# Gacha audio sources

- `gacha_spin.ogg`: existing user-supplied Golden Sign recording, retained from 1.5.0.
- `gacha_ab.ogg`: full user-supplied `Zenless Zone Zero - Gacha Character Pull Animations - Rubhen925.mp3`, converted from MP3 to streaming Vorbis. Duration: approximately 152.45 seconds; playback begins at the start of the supplied recording and loops while waiting for confirmation.
- `gacha_vocal.ogg`: vocal section of the existing Golden Sign recording, starting at 8 seconds, used when focusing on an S from ten pulls.
- `channel_static.ogg`: synthetic short TV tuning noise introduced in 1.6.0.
- `gacha_reveal.ogg`: original 0.9-second synthesized noise swoosh, bass impact and chime for the slide/focus transition.
- Agent dialogue sources and missing-voice coverage remain documented in `VOICE_SOURCES.md`.
