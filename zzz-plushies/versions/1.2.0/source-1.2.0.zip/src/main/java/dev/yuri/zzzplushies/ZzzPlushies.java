package dev.yuri.zzzplushies;

import dev.yuri.zzzplushies.block.PlushBlock;
import dev.yuri.zzzplushies.block.PlushBlockEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.LinkedHashMap;
import java.util.Map;

@Mod(ZzzPlushies.MOD_ID)
public final class ZzzPlushies {
    public static final String MOD_ID = "zzzplushies";
    private static final DeferredRegister<net.minecraft.world.level.block.Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, MOD_ID);
    private static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, MOD_ID);
    private static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, MOD_ID);
    private static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MOD_ID);

    public static final Map<String, RegistryObject<PlushBlock>> PLUSHES = new LinkedHashMap<>();
    public static final RegistryObject<Item> PLUSH_BASE = ITEMS.register("plush_base",
            () -> new Item(new Item.Properties()));

    static {
        for (String id : PlushCatalog.IDS) {
            RegistryObject<PlushBlock> block = BLOCKS.register(id,
                    () -> new PlushBlock());
            PLUSHES.put(id, block);
            ITEMS.register(id, () -> new BlockItem(block.get(), new Item.Properties()));
        }
    }

    public static final RegistryObject<BlockEntityType<PlushBlockEntity>> PLUSH_BLOCK_ENTITY =
            BLOCK_ENTITIES.register("plush", () -> BlockEntityType.Builder.of(
                    PlushBlockEntity::new,
                    PLUSHES.values().stream().map(RegistryObject::get).toArray(PlushBlock[]::new)
            ).build(null));

    public static final RegistryObject<CreativeModeTab> PLUSH_TAB = TABS.register("plushies",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.zzzplushies.plushies"))
                    .icon(() -> new ItemStack(PLUSHES.get("anby_demara").get()))
                    .displayItems((parameters, output) -> {
                        output.accept(PLUSH_BASE.get());
                        for (RegistryObject<PlushBlock> block : PLUSHES.values()) {
                            output.accept(block.get());
                        }
                    })
                    .build());

    public ZzzPlushies() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        BLOCKS.register(bus);
        ITEMS.register(bus);
        BLOCK_ENTITIES.register(bus);
        TABS.register(bus);
    }
}
