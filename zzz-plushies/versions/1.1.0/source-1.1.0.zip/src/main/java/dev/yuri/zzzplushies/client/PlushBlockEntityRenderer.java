package dev.yuri.zzzplushies.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import dev.yuri.zzzplushies.ZzzPlushies;
import dev.yuri.zzzplushies.block.PlushBlock;
import dev.yuri.zzzplushies.block.PlushBlockEntity;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.registries.ForgeRegistries;

public final class PlushBlockEntityRenderer implements BlockEntityRenderer<PlushBlockEntity> {
    private final PlayerModel<LivingEntity> model;

    public PlushBlockEntityRenderer(BlockEntityRendererProvider.Context context) {
        model = new PlayerModel<>(context.bakeLayer(ModelLayers.PLAYER), false);
        model.head.xRot = -0.25F;
        model.hat.copyFrom(model.head);
        model.leftLeg.xRot = -(float) Math.PI / 2.0F;
        model.rightLeg.xRot = -(float) Math.PI / 2.0F;
        model.leftLeg.yRot = -0.35F;
        model.rightLeg.yRot = 0.35F;
        model.leftArm.xRot = -(float) Math.PI / 2.0F;
        model.rightArm.xRot = -(float) Math.PI / 2.0F;
        model.leftArm.yRot = -0.18F;
        model.rightArm.yRot = 0.18F;
        model.leftSleeve.copyFrom(model.leftArm);
        model.rightSleeve.copyFrom(model.rightArm);
        model.leftPants.copyFrom(model.leftLeg);
        model.rightPants.copyFrom(model.rightLeg);
    }

    @Override
    public void render(PlushBlockEntity plush, float partialTick, PoseStack pose,
                       MultiBufferSource buffers, int light, int overlay) {
        ResourceLocation key = ForgeRegistries.BLOCKS.getKey(plush.getBlockState().getBlock());
        if (key == null) return;
        ResourceLocation texture = new ResourceLocation(ZzzPlushies.MOD_ID,
                "textures/entity/" + key.getPath() + ".png");
        VertexConsumer vertices = buffers.getBuffer(RenderType.entityCutoutNoCull(texture));
        pose.pushPose();
        pose.translate(0.5D, 0.0D, 0.5D);
        pose.mulPose(Axis.YP.rotationDegrees(180.0F - plush.getBlockState().getValue(PlushBlock.FACING).toYRot()));

        // The body reaches the floor; each limb is horizontal and just touches y=0.
        // Separate scales retain the original player-skin UVs while giving the plush a larger head.
        pose.pushPose();
        pose.translate(0.0D, 8.3D / 16.0D, 0.0D);
        pose.scale(0.85F, -0.72F, 1.45F);
        model.body.render(pose, vertices, light, OverlayTexture.NO_OVERLAY);
        model.jacket.render(pose, vertices, light, OverlayTexture.NO_OVERLAY);
        pose.popPose();

        pose.pushPose();
        pose.translate(0.0D, 6.8D / 16.0D, 0.0D);
        pose.scale(1.0F, -1.0F, 1.0F);
        model.head.render(pose, vertices, light, OverlayTexture.NO_OVERLAY);
        model.hat.render(pose, vertices, light, OverlayTexture.NO_OVERLAY);
        pose.popPose();

        pose.pushPose();
        pose.translate(0.0D, 6.0D / 16.0D, -1.5D / 16.0D);
        pose.scale(0.75F, -0.75F, 0.50F);
        renderPair(model.leftArm, model.leftSleeve, pose, vertices, light);
        renderPair(model.rightArm, model.rightSleeve, pose, vertices, light);
        pose.popPose();

        pose.pushPose();
        pose.translate(0.0D, 10.5D / 16.0D, -1.0D / 16.0D);
        pose.scale(0.75F, -0.75F, 0.50F);
        renderPair(model.leftLeg, model.leftPants, pose, vertices, light);
        renderPair(model.rightLeg, model.rightPants, pose, vertices, light);
        pose.popPose();
        pose.popPose();
    }

    private static void renderPair(ModelPart base, ModelPart clothing, PoseStack pose,
                                   VertexConsumer vertices, int light) {
        base.render(pose, vertices, light, OverlayTexture.NO_OVERLAY);
        clothing.render(pose, vertices, light, OverlayTexture.NO_OVERLAY);
    }
}
