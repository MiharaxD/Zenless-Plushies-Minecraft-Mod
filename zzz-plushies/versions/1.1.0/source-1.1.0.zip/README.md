# ZZZ Plushies — Forge 1.20.1

Small, placeable, seated decorative plushies made from the selected Zenless Zone Zero Minecraft skins. Each agent has its own block and item. The plushes face the player when placed, sit flush on the ground, can be broken by hand and drop themselves. They appear in the **ZZZ Plushies** creative tab.

In survival, craft four **Plush Bases** with one white wool surrounded by four string, then use a stonecutter to choose a character plush. This recipe keeps the character selection in one familiar screen.

The 58 currently selected agents are listed with original skin artists and links in [SKIN_SOURCES.md](SKIN_SOURCES.md). Pyrois and Claret Flint need identifiable source skins before they can be added. Roxy is included in advance of her September 30, 2026 release. NameMC does not identify the Starlight Billy skin by name; verify that visual before distributing the mod.

## Build

Requires Java 17. Run `gradlew.bat build` from this directory. The mod JAR will be in `build/libs/` and goes in the `mods` folder of a Forge 1.20.1 client and server. No other mods are required.

The resources can be regenerated from `../assets/zzz-plushie-skins/` by running `python generate_assets.py` with Pillow installed.

Version 1.1.0 gives the plushes a wider head and short, chunky arms and legs. The previous JAR and source snapshot are preserved in `versions/1.0.0/`.

This is an unofficial fan project. Do not redistribute the third-party skins without checking their creators' terms.
