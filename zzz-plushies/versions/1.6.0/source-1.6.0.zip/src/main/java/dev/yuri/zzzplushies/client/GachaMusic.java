package dev.yuri.zzzplushies.client;

import dev.yuri.zzzplushies.PlushCatalog;
import dev.yuri.zzzplushies.ZzzPlushies;
import dev.yuri.zzzplushies.gacha.GachaGrade;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ZzzPlushies.MOD_ID, value = Dist.CLIENT)
public final class GachaMusic {
    private static final GachaGrade[] CHANNELS = {
            GachaGrade.B, GachaGrade.A, GachaGrade.B, GachaGrade.A,
            GachaGrade.S, GachaGrade.B, GachaGrade.A
    };
    private static SoundInstance music;
    private static SoundInstance voice;
    private static GachaGrade outcome;
    private static ItemStack reward = ItemStack.EMPTY;
    private static int plushIndex = -1;
    private static int ticks;
    private static int lastChannel = -1;
    private static boolean won;
    private static boolean voucher;

    private GachaMusic() {}

    public static void play(GachaGrade grade, int index, ItemStack item, boolean wonChoice, boolean earnedVoucher) {
        Minecraft minecraft = Minecraft.getInstance();
        if (music != null) minecraft.getSoundManager().stop(music);
        if (voice != null) minecraft.getSoundManager().stop(voice);
        outcome = grade;
        plushIndex = index;
        reward = item.copy();
        won = wonChoice;
        voucher = earnedVoucher;
        ticks = 0;
        lastChannel = -1;
        voice = null;
        music = SimpleSoundInstance.forUI(ZzzPlushies.GACHA_SPIN_SOUND.get(), 1.0F, 0.55F);
        minecraft.getSoundManager().play(music);
    }

    public static boolean isRevealing() {
        return outcome != null && ticks < (outcome == GachaGrade.S ? 265 : 225);
    }

    public static int ticks() { return ticks; }
    public static ItemStack reward() { return reward; }
    public static GachaGrade outcome() { return outcome; }

    public static GachaGrade visibleChannel() {
        if (outcome == null || ticks < 18) return null;
        if (ticks >= 150) return outcome;
        return CHANNELS[Math.floorMod(channelIndex(ticks), CHANNELS.length)];
    }

    private static int channelIndex(int time) {
        return time < 118 ? (time - 18) / 8 : 13 + (time - 118) / 4;
    }

    @SubscribeEvent
    public static void clientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END || outcome == null || Minecraft.getInstance().isPaused()) return;
        Minecraft minecraft = Minecraft.getInstance();
        ticks++;
        if (ticks < 150 && ticks >= 18) {
            int channel = channelIndex(ticks);
            if (channel != lastChannel) {
                lastChannel = channel;
                minecraft.getSoundManager().play(SimpleSoundInstance.forUI(
                        ZzzPlushies.CHANNEL_STATIC_SOUND.get(), 0.93F + (channel % 4) * 0.05F, 0.36F));
            }
        }
        if (ticks == 150) {
            if (outcome != GachaGrade.S && music != null) {
                minecraft.getSoundManager().stop(music);
                music = null;
            }
            if (minecraft.player != null) {
                minecraft.player.displayClientMessage(Component.translatable(
                        outcome == GachaGrade.S ? (won ? "message.zzzplushies.won" : "message.zzzplushies.lost")
                                : "message.zzzplushies.reward", reward.getHoverName()), false);
                if (voucher) minecraft.player.displayClientMessage(
                        Component.translatable("message.zzzplushies.token"), false);
            }
        }
        if (ticks == 165 && outcome == GachaGrade.S && plushIndex >= 0 && plushIndex < PlushCatalog.IDS.length) {
            var sound = ZzzPlushies.AGENT_VOICES.get(PlushCatalog.IDS[plushIndex]);
            if (sound != null) {
                voice = SimpleSoundInstance.forUI(sound.get(), 1.0F);
                minecraft.getSoundManager().play(voice);
            }
        }
    }
}
