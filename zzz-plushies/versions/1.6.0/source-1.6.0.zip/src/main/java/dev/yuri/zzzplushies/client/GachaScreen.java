package dev.yuri.zzzplushies.client;

import dev.yuri.zzzplushies.PlushCatalog;
import dev.yuri.zzzplushies.gacha.GachaMenu;
import dev.yuri.zzzplushies.gacha.GachaGrade;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.registries.ForgeRegistries;

public final class GachaScreen extends AbstractContainerScreen<GachaMenu> {
    public GachaScreen(GachaMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        imageWidth = 220;
        imageHeight = 150;
    }

    @Override
    protected void init() {
        super.init();
        addRenderableWidget(Button.builder(Component.literal("◀"), b -> press(1))
                .bounds(leftPos + 25, topPos + 48, 25, 20).build());
        addRenderableWidget(Button.builder(Component.literal("▶"), b -> press(2))
                .bounds(leftPos + 170, topPos + 48, 25, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("button.zzzplushies.spin"), b -> press(0))
                .bounds(leftPos + 64, topPos + 112, 92, 22).build());
    }

    private void press(int id) {
        if (GachaMusic.isRevealing()) return;
        Minecraft.getInstance().gameMode.handleInventoryButtonClick(menu.containerId, id);
    }

    @Override
    protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        graphics.fill(leftPos, topPos, leftPos + imageWidth, topPos + imageHeight, 0xFF111725);
        graphics.fill(leftPos + 3, topPos + 3, leftPos + imageWidth - 3, topPos + imageHeight - 3, 0xFF27334B);
        graphics.fill(leftPos + 56, topPos + 31, leftPos + 164, topPos + 85, 0xFF111725);
        String plushId = PlushCatalog.IDS[Math.floorMod(menu.selected(), PlushCatalog.IDS.length)];
        ItemStack plush = new ItemStack(ForgeRegistries.ITEMS.getValue(new ResourceLocation("zzzplushies", plushId)));
        graphics.renderItem(plush, leftPos + 102, topPos + 38);
        graphics.drawCenteredString(font, plush.getHoverName(), leftPos + 110, topPos + 69, 0xFFF5E7CE);
    }

    @Override
    protected void renderLabels(GuiGraphics graphics, int mouseX, int mouseY) {
        graphics.drawCenteredString(font, title, imageWidth / 2, 12, 0xFFF5E7CE);
        graphics.drawString(font, Component.translatable("gui.zzzplushies.tapes", menu.tapes()), 13, 91, 0xFFFFFF, false);
        graphics.drawString(font, Component.translatable("gui.zzzplushies.pity", menu.pity(), 75), 94, 91, 0xFFFFFF, false);
        graphics.drawString(font, Component.translatable("gui.zzzplushies.losses", menu.losses(), 2), 13, 102, 0xF5C6C6, false);
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics);
        super.render(graphics, mouseX, mouseY, partialTick);
        renderTooltip(graphics, mouseX, mouseY);
        if (GachaMusic.isRevealing()) {
            graphics.flush();
            graphics.pose().pushPose();
            graphics.pose().translate(0, 0, 500);
            renderTelevision(graphics);
            graphics.flush();
            graphics.pose().popPose();
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        return GachaMusic.isRevealing() || super.mouseClicked(mouseX, mouseY, button);
    }

    private void renderTelevision(GuiGraphics graphics) {
        int tick = GachaMusic.ticks();
        boolean revealed = tick >= 150;
        GachaGrade channel = GachaMusic.visibleChannel();
        int width = Math.min(this.width - 24, 356);
        int height = Math.min(this.height - 24, 258);
        int x = (this.width - width) / 2;
        int y = (this.height - height) / 2;
        int sx = x + 18;
        int sy = y + 26;
        int sw = width - 90;
        int sh = height - 53;

        graphics.fill(0, 0, this.width, this.height, 0xDD030913);
        graphics.fill(x + 9, y + 10, x + width + 9, y + height + 10, 0xAA000000);
        graphics.fill(x, y, x + width, y + height, 0xFF070C13);
        graphics.fill(x + 3, y + 3, x + width - 3, y + height - 3, 0xFF313A49);
        graphics.fill(x + 9, y + 9, x + width - 9, y + height - 9, 0xFF121B29);
        graphics.fill(sx - 4, sy - 4, sx + sw + 4, sy + sh + 4, 0xFF05080D);

        int accent = channel == GachaGrade.S ? 0xFFFFD44F
                : channel == GachaGrade.A ? 0xFFCF61F2 : 0xFF53C8FA;
        int background = channel == GachaGrade.S ? 0xFF382B10
                : channel == GachaGrade.A ? 0xFF251438 : 0xFF10283A;
        graphics.fill(sx, sy, sx + sw, sy + sh, background);
        graphics.fill(sx, sy, sx + sw, sy + 3, accent);
        graphics.fill(sx, sy + sh - 3, sx + sw, sy + sh, accent);

        for (int line = sy + 5; line < sy + sh - 4; line += 4) {
            graphics.fill(sx + 2, line, sx + sw - 2, line + 1, 0x3A000000);
        }
        if (!revealed) {
            for (int stripe = 0; stripe < 5; stripe++) {
                int yy = sy + 14 + Math.floorMod(tick * (stripe + 3) * 7 + stripe * 43, sh - 31);
                int xx = sx + 7 + Math.floorMod(tick * 13 + stripe * 29, 28);
                graphics.fill(xx, yy, Math.min(sx + sw - 7, xx + 45 + stripe * 18), yy + 2,
                        stripe % 2 == 0 ? 0x66E5F8FF : 0x66586380);
            }
        }

        graphics.drawCenteredString(font, Component.translatable(revealed
                ? "gui.zzzplushies.signal_locked" : "gui.zzzplushies.signal_search"),
                sx + sw / 2, sy + 10, revealed ? accent : 0xFFC8D6E3);
        if (channel != null) {
            graphics.pose().pushPose();
            graphics.pose().translate(sx + sw / 2.0F, sy + sh / 2.0F - 10, 0);
            graphics.pose().scale(8.0F, 8.0F, 1.0F);
            graphics.drawCenteredString(font, channel.name(), 0, -4, accent);
            graphics.pose().popPose();
        }

        if (revealed) {
            ItemStack item = GachaMusic.reward();
            graphics.renderItem(item, sx + sw / 2 - 8, sy + sh - 49);
            String name = font.plainSubstrByWidth(item.getHoverName().getString(), sw - 18);
            graphics.drawCenteredString(font, name, sx + sw / 2, sy + sh - 27, 0xFFFFFFFF);
        } else {
            graphics.drawCenteredString(font, "◀ B  A  S ▶", sx + sw / 2, sy + sh - 23, 0xFFCAD4DD);
        }

        int controlsX = sx + sw + 12;
        graphics.fill(controlsX, sy + 8, controlsX + 29, sy + 37, 0xFF03070C);
        graphics.fill(controlsX + 5, sy + 13, controlsX + 24, sy + 32, accent);
        graphics.fill(controlsX + 9, sy + 17, controlsX + 20, sy + 28, 0xFF151D26);
        graphics.fill(controlsX, sy + 48, controlsX + 29, sy + 76, 0xFF03070C);
        graphics.fill(controlsX + 5, sy + 53, controlsX + 24, sy + 72, 0xFF71808C);
        graphics.fill(controlsX + 9, sy + 57, controlsX + 20, sy + 68, 0xFF151D26);
        for (int slot = 0; slot < 8; slot++) {
            graphics.fill(controlsX + 2, sy + 92 + slot * 8,
                    controlsX + 28, sy + 95 + slot * 8, 0xFF01040A);
        }
        graphics.fill(x + width / 2 - 2, y - 11, x + width / 2 + 2, y + 3, 0xFF67717D);
        graphics.fill(x + width / 2 - 36, y - 13, x + width / 2 - 14, y - 10, 0xFF67717D);
        graphics.fill(x + width / 2 + 14, y - 13, x + width / 2 + 36, y - 10, 0xFF67717D);
    }
}
