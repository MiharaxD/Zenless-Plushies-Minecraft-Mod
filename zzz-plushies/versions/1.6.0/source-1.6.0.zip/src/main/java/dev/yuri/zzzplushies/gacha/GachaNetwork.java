package dev.yuri.zzzplushies.gacha;

import dev.yuri.zzzplushies.ZzzPlushies;
import dev.yuri.zzzplushies.client.GachaMusic;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

public final class GachaNetwork {
    private static final String VERSION = "1";
    private static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(ZzzPlushies.MOD_ID, "gacha"), () -> VERSION,
            VERSION::equals, VERSION::equals);

    private GachaNetwork() {}

    public static void register() {
        CHANNEL.registerMessage(0, SpinResult.class, (message, buffer) -> {
                    buffer.writeVarInt(message.grade.ordinal());
                    buffer.writeVarInt(message.plushIndex);
                    buffer.writeItem(message.reward);
                    buffer.writeBoolean(message.won);
                    buffer.writeBoolean(message.voucher);
                },
                buffer -> new SpinResult(GachaGrade.fromNetwork(buffer.readVarInt()), buffer.readVarInt(),
                        buffer.readItem(), buffer.readBoolean(), buffer.readBoolean()), (message, contextSupplier) -> {
                    var context = contextSupplier.get();
                    context.enqueueWork(() -> GachaMusic.play(message.grade, message.plushIndex,
                            message.reward, message.won, message.voucher));
                    context.setPacketHandled(true);
                });
    }

    public static void playFor(ServerPlayer player, GachaGrade grade, int plushIndex,
                               ItemStack reward, boolean won, boolean voucher) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),
                new SpinResult(grade, plushIndex, reward.copy(), won, voucher));
    }

    private record SpinResult(GachaGrade grade, int plushIndex, ItemStack reward,
                              boolean won, boolean voucher) {}
}
